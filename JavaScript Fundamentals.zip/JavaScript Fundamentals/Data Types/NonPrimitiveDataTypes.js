// Object Datatype
var emp = new Object();
emp.name = "Teja";
emp.id = 101;
emp.location = "Mumbai";

console.log(emp.id);
console.log(emp.name);
console.log(emp.location);

// Array Datatype
var arr = new Array(1,2,3,4,5);
console.log(arr);

