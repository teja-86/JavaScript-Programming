function add(){
    let a = 10;
    let b = 20;
    return a + b;
}

var a = add();
console.log(a);

