var emp = new Array("Teja","Ashok","Jhon");  
for (i=0;i<emp.length;i++){  
console.log(emp[i]);  
}  

