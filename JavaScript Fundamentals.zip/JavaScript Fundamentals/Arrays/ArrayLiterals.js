var emp=["Teja","Ashok","Jhon"];  
for (i=0;i<emp.length;i++){  
console.log(emp[i]);  
}  