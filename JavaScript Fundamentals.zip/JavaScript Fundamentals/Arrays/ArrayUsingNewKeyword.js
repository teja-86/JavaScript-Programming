var i;  
var emp = new Array();  
emp[0] = "Teja";  
emp[1] = "Ashok";  
emp[2] = "John";  
  
for (i=0;i<emp.length;i++){  
console.log(emp[i]);  
}  