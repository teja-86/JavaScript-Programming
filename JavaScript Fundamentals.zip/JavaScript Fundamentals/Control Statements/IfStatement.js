var a=10;  
if(a>5){  
console.log("value of a is greater than 5");  
}  