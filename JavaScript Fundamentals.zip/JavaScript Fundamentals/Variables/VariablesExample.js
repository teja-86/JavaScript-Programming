var x = 10;  
var y = 20;  
var z = --y;  
console.log(z);  
