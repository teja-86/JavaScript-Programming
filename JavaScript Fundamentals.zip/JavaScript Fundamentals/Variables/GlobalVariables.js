var data=200; //gloabal variable  
function method1(){  
console.log(data);  
}  
function method2(){  
console.log(data);  
}  
method1(); //calling JavaScript function  
method2();  