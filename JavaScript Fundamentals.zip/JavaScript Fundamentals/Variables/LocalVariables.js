function print(){  
    var x=10;//local variable 
    console.log(x); 
    } 

print();