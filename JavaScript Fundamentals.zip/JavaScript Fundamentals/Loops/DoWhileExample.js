var i=21;  
do{  
console.log(i);  
i++;  
}while (i<=25);  