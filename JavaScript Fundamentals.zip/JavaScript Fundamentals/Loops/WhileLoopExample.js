var i=11;  
while (i<=15)  
{  
console.log(i);  
i++;  
}  