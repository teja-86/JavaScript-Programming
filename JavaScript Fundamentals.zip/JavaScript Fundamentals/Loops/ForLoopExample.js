// For Loop in Js
for(let i = 0;i<10;i++){
    console.log(i);
}

for(let a = 10;a<=20;a++){
    if(a%2 == 0){
        console.log(a);
    }
}