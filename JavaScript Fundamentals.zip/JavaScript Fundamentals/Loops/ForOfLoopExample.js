const cars = ["India", "Us", "America"];

let text = "";
for (let x of cars) {
  text += x + " ";
}

console.log(text);