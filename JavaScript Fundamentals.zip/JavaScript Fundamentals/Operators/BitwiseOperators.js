// AND Operator (&)
let x = 5 & 7;
console.log(x);
// OR Operator
let y = 5 | 10;
console.log(y);
// XOR Operator
let z = 3 ^ 9;
console.log(z);
// Left Shift
let a = 5 << 7;
console.log(a);
// Right Shift
let b = 8 >> 6;
console.log(b);
// Zerofill Right Shift
let c = 6 >>> 7;
console.log(c);
