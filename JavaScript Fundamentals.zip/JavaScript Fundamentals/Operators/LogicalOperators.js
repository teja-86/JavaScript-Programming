// Logical AND (&&)
let name = "Teja";
let myname = "Teja";
let a = 10;
let b = 12;
let c = 12;

if(a<b && c == b){
    console.log("a is lessthan b and c is same as b");
}

if(b==c || a>b){
    console.log("Second if Statement is true");
}
if(1){
    console.log(!(a==b));
}

