// All Operators Examples in Js

// ArithMatic Operators - (*,-,%,/,+)
var a = 10;
var b = 20;
console.log(a + b);
console.log(a - b);
console.log(a * b);
console.log(a / b);
console.log(a % b);