let b = 10;
let c = 20;

(b<c) ? console.log("True") : console.log("False");;