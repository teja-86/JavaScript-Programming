var a = typeof "Hello";
console.log(a);

var b = typeof 12;
console.log(b);

var c = typeof true;
console.log(c);